<template>
  <div id="app">
    <router-view/>
    <div class="nav">
      <div class="item" @click="onHome">
        <img src="./assets/index/shouye2.png">
        <p>首页</p>
      </div>
      <div class="item" @click="onRouter" >
        <img src="./assets/index/shangcheng2.png">
        <p>资产</p>
      </div>
      <div class="item" @click="onRouter">
        <img src="./assets/index/zichan2.png">
        <p>商城</p>
      </div>
      <div class="item" @click="onRouter">
        <img src="./assets/index/wo2.png">
        <p>我的</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return{

    }
  },
  mounted(){

  },
  methods:{
    onRouter() {
      this.$router.push({ path: "/Demo" });
    },
    onHome(){
      this.$router.push({ path: "/" });
    }
  }
}
</script>


<style lang="scss">
*{
  margin: 0;
  padding: 0;
}
html,body{
  width: 100%;
  overflow-x: hidden;
  font-size: 12px;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.nav{
  position: fixed;
  background: #0290f4;
  color: #fff;
  left: 0;
  bottom: 0;
  width: 100%;
  height: .8rem;
  display: flex;
  padding: .1rem 0;
  .item{
    border-right: 1px solid #1682d0;
    &:last-child{
      border: none;
    }
    img{
      width: .5rem;
      display: block;
      margin: 0 auto;
    }
    flex: 1;
    font-size: .24rem;
    text-align: center;
  }
}
</style>
