<template>
  <div class="home">
    <div class="banner">
      <img src="../assets/index/erweima.png">
      <p>UID:8485</p>
    </div>
    <div class="box">
      <div class="item l" @click="onRouter">
        <img src="../assets/index/libao.png">
        <p>我的资产</p>
        <p class="red">4050.05</p>
      </div>
      <div class="item c" @click="onRouter">
        <img src="../assets/index/erweima.png">
        <p>扫一扫</p>
      </div>
      <div class="item r" @click="onRouter">
        <img src="../assets/index/zuan.png">
        <p>我的积分</p>
        <p class="red">1489.96</p>
      </div>
    </div>
    <Swiper class="img">
       <Slide>
         <img src="../assets/index/index-center1.png">
       </Slide>
       <Slide>
         <img src="../assets/index/index-center2.png">
       </Slide>
       <Slide>
         <img src="../assets/index/index-center3.png">
       </Slide>
    </Swiper>
    
    <div class="nav-box">
      <div class="li">
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-xia.png">
          <p>转出</p>
        </div>
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-shang.png">
          <p>转入</p>
        </div>
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-xiangzi.png">
          <p>买入</p>
        </div>
      </div>
      <div class="li">
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-ok.png">
          <p>卖出</p>
        </div>
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-zuan.png">
          <p>数字资产</p>
        </div>
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-cart.png">
          <p>商城</p>
        </div>
      </div>
      <div class="li">
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-liwu.png">
          <p>分享</p>
        </div>
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-juxing.png">
          <p>积分兑换</p>
        </div>
        <div class="item" @click="onRouter">
          <img src="../assets/index/icon-geren.png">
          <p>团队</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Swiper, Slide } from "vue-swiper-component";
export default {
  name: "Main",
  data() {
    return {
      msg: "Welcome to Your Vue.js App",
      list:["../assets/index/index-center1.png","../assets/index/index-center2.png","../assets/index/index-center3.png"]
    };
  },
   methods:{
    onRouter() {
      this.$router.push({ path: "/Demo" });
    }
  },
  components: {
    Swiper,
    Slide
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.home {
  .banner {
    width: 100%;
    height: 2.37rem;
    background: url(../assets/index/index-header.png) center no-repeat;
    background-size: 100% auto;
    color: #fff;
    box-sizing: border-box;
    padding: 0.5rem 0;
    font-size: 0.26rem;
    img {
      display: block;
      width: 1rem;
      height: 1rem;
      border-radius: 100%;
      margin: 0 auto;
    }
    p {
      padding: 0.1rem 0;
    }
  }
  .box {
    display: flex;
    padding: 0.3rem 0;
    .item {
      flex: 1;
      text-align: center;
      &.l{
        padding-right: 1rem;
      }
      &.r{
        padding-left: 1rem;
      }
      &.c{
        p{
          padding: .2rem 0;
        }
      }
      .red{
        color: red;
      }
      img {
        display: block;
        width: 1rem;
        margin: 0 auto;
      }
    }
  }
  .img {
    img {
      width: 100%;
    }
  }
  .nav-box {
    .li {
      display: flex;

      border-bottom: 1px solid #d2e9fd;
      .item {
        padding: 0.16rem 0;
        flex: 1;
        text-align: center;
        font-size: 0.26rem;
        border-right: 1px solid #d2e9fd;
        &:last-child {
          border: none;
        }
        img {
          display: block;
          width: 0.8rem;
          margin: 0 auto;
        }
      }
    }
  }
}
</style>
