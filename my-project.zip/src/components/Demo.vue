<template>
    <div class="demo">
        我的跳转页面
    </div>
</template>
<script>
export default {
    name: "Demo",
}
</script>
<style lang="scss" scoped>

</style>

